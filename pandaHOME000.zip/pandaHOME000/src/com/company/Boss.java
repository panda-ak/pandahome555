package com.company;

public class Boss {

    private int health;
    private int damage;
    private int mental;

    public Boss() {

        this.health = health;
        this.health = damage;
        this.mental = mental;
    }

    public Boss(int health, int damage, int mental){
    }
    public int getHealth(){
        return health;
    }
    public void getHealth(int health){
        this.health = health;
    }

    public int getDamage() {
        return damage;
    }
    public void getDamage(int damage){
        this.damage = damage;
    }

    public void setMental(int mental){
        this.mental = mental;
    }


    public int setMental() {
        return 0;
    }
}
